1. How to compile?
Please type the following command.
$ make

Then, two executable files, ps3-nishida-1 and ps3-nishida-2 will be generated in the same directory.

2. How to run this program?
[3D convex hull]
Please type the following command for 3d convex hull.
$ ./ps3-nishida-1

Then, type the point data as specified in the problem set 3 instruction.

[Delaunay triangulation]
Please type the following command for 3d convex hull.
$ ./ps3-nishida-2

Then, type the point data as specified in the problem set 3 instruction.
